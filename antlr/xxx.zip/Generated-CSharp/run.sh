./bin/Debug/net8.0/Test.exe "$@"
