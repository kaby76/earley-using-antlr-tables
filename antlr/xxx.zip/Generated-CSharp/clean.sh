# Generated from trgen 0.23.27
dotnet clean Test.csproj
rm -rf bin obj
rm -f ExLexer.cs ExParser.cs 
